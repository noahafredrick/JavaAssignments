/*
 * Noah Fredrick
 * Java Programming 1
 * 1 November 2019
 * Tomie Gartland
 * 
 */

import java.io.*; 

public class HomeworkOOP {
		//-----------------------------------------------------------------------------------------------------------------------
		// Name: Void Main
		// Abstract: Where it all happens
		//-----------------------------------------------------------------------------------------------------------------------
		public static void main( String astrCommandLine[ ]) {
		ShowPolyformism();	    
		}
		

		static void ShowPolyformism()
		{
			//Populate the zoo
			CAnimal[] aclsZoo = new CAnimal[7];

			CDog clsBuster = new CDog();
			clsBuster.SetType("Dog");
			clsBuster.SetName("Buster");
			clsBuster.SetAge(11);
			clsBuster.SetWeight(40);

			CCat clsSunny = new CCat();
			clsSunny.SetName("Sunny");
			clsSunny.SetType("Cat");

			CDuck clsDaffy = new CDuck();
			clsDaffy.SetName("Daffy");
			clsDaffy.SetType("Duck");

			CCow clsBessie = new CCow();
			clsBessie.SetName("Bessie");
			clsBessie.SetType("Cow");
			clsBessie.SetColor("");

			CDragon clsSmaugh = new CDragon();
			clsSmaugh.SetName("Smaugh");
			clsSmaugh.SetType("Dragon");
			clsSmaugh.SetHeads(3);

			CTrainedDog clsFifi = new CTrainedDog();
			clsFifi.SetName("Fifi");
			clsFifi.SetType("Trained Dog");
			clsFifi.SetAge(2);
			clsFifi.SetWeight(10);
			clsFifi.SetBreed("Poodle");


			aclsZoo[0] = (CAnimal)clsBuster;
			aclsZoo[1] = (CAnimal)clsSunny;
			aclsZoo[2] = (CAnimal)clsDaffy;
			aclsZoo[3] = null;
			aclsZoo[4] = (CAnimal)clsBessie;
			aclsZoo[5] = (CAnimal)clsSmaugh;
			aclsZoo[6] = (CAnimal)clsFifi;

			for(int intIndex = 0; intIndex < aclsZoo.length; intIndex += 1)
				{
				if(aclsZoo[intIndex]!= null)
				{
					System.out.println("Animal in cage #" + (intIndex + 1));
					System.out.println("Name: " + aclsZoo[intIndex].GetName());
					System.out.println("Type: " + aclsZoo[intIndex].GetType());
					aclsZoo[intIndex].MakeNoise();
		
					String strAnimalType = "";
		
					strAnimalType = aclsZoo[intIndex].GetType();
		
					if(strAnimalType.equals("Dog") == true)
					{
						((CDog)aclsZoo[intIndex]).Fetch();
					}
		
					else if (strAnimalType.contentEquals("Trained Dog") == true)
					{
						((CTrainedDog) aclsZoo[intIndex]).PlayDead();
						((CTrainedDog) aclsZoo[intIndex]).Print();
					}
					else if (strAnimalType.equals("Cow") == true)
					{
						((CCow) aclsZoo[intIndex]).Graze();
						System.out.println("Color is: " +((CCow) aclsZoo[intIndex]).GetColor());
					}
		
					else if(strAnimalType.equals("Dragon") == true)
					{
						((CDragon) aclsZoo[intIndex]).BreatheFire();
					}
		
					System.out.println("");
		
		
				}
		}
	}
}
