//Trained dog CLASS
				public class CTrainedDog extends CDog
				{
					private String m_strBreed = "";
					
					public void SetBreed(String strNewBreed)
					{
						int intStopIndex = 0;
						
						intStopIndex = strNewBreed.length();
						
						if(intStopIndex > 10)
						{
							intStopIndex = 10;
						}
						
						m_strBreed = strNewBreed.substring(0, intStopIndex);
					}
					
					public String GetBreed()
					{
						return m_strBreed;
					}
					
					public void PlayDead()
					{
						if(GetAge() < 5)
						{
							System.out.println("Bang! You got me!");
						}
						
						else
						{
							System.out.println("Treat first. Trick second.");
						}
					}
					
					public void FetchNewsPaper()
					{
						if(GetAge()< 2)
						{
							System.out.println("I'm too young.");
						}
						else
						{
							System.out.println("Here's your paper.");
						}
					}
					
					public void Print()
					{
						System.out.println("Name:   " + GetName());
						System.out.println("Age:    " + GetAge());
						System.out.println("Weight: " + GetWeight());
						System.out.println("Breed:  " + GetBreed());
						
						MakeNoise();
						Fetch();
						PlayDead();
						
						System.out.println("");
						System.out.println("");
					}
				}
