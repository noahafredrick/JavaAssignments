
public class Motorbike extends Vehicle
		{
		private String m_strHowToDrive = "";
			public void SetHowToDrive(String strHowToDrive)
				{
					m_strHowToDrive = "Handlebars";
				}
	
			public String GetHowToDrive()
				{
					return m_strHowToDrive;
				}		
		}
