
public class Trailer extends Vehicle
		{
		private String m_strHowToDrive = "";
		private int m_intMPG = 0;
		
			public void SetHowToDrive(String strHowToDrive)
				{
					m_strHowToDrive = "Another Vehicle";
				}
	
			public String GetHowToDrive()
				{
					return m_strHowToDrive;
				}		
			
			//Trailers can't drive, must be zero
			public void SetMPG ( int intMPG )
			{
				m_intMPG = 0;
			}
			
			public int GetMPG( )
			{
				return m_intMPG;
			}
			
		}
