public class Car extends Vehicle
		{
		private String m_strHowToDrive = "";
			public void SetHowToDrive(String strHowToDrive)
				{
					m_strHowToDrive = "Steering Wheel";
				}
	
			public String GetHowToDrive()
				{
					return m_strHowToDrive;
				}		
		}