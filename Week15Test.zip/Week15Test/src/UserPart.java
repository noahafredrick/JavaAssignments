
/**
 * @author Noah
 *
 */

//import for sql Connection, DriverManager, ResultSet, Statement
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.*;	// For connecting to SQL Server
import java.util.regex.Matcher; //for regex
import java.util.regex.Pattern;
	
	
public class UserPart {

	/**
	 * @param args
	 */
	
	//define the Connection
	private static Connection m_conAdministrator;
	//define the table, primary key, and column

	/**
	* Abstract: Main Method
	* @author Noah Fredrick
	* @since  12/11/2019
	* @version 1.0
			*/
	
			public static void main(String[] args) {
		 
				
				//Database loading
		       try {
		        	
		    			// Can we connect to the database?
		    			if ( OpenDatabaseConnectionSQLServer( ) == true )
		    			{	
							// Yes, load the teams list
		    				LoadListFromDatabase( "TVehicles", "intVehicleID" , "strType" );
		    			}
		    			else
		    			{
		    				// No, warn the user ...
		    				System.out.println("Error loading the table");
		    			}
		    			
		    				System.out.println("Process Complete");
		    		
		    		
		       			}
		       catch 	(Exception e) {
		            		System.out.println("An I/O (location: database loading) error occurred: " + e.getMessage());
		        		}
		        
		        
		       try {
		    	   		
		    	   		//Input --------------------------------------------------------------------------------
		        		System.out.println("\n" + "Please enter your name: ");
		        		String strName = ReadStringFromUser();
		        		
		        		boolean bool = false;
		        		String strPhone = "";
		        		String strEmail = "";
		        		
		        		while( bool != true) {
		        		System.out.println("Please enter your phone number like XXX-XXXXXXX");
		        		strPhone = ReadStringFromUser();
		        		bool = IsValidPhoneNumber(strPhone);
		        		}
		        		
		        		bool = false;
		        		while( bool != true) {
		        		System.out.println("Please enter your email address like name@domain.com");
			        	strEmail = ReadStringFromUser();
			        	bool = IsValidEmail(strEmail);
		        		}
		        		
			        	System.out.println("Please enter number of rental days:");
			        	int intDays = ReadIntegerFromUser();
			        	
			        	System.out.println("Please enter number of vehicles to rent:");
			        	int intVehicles = ReadIntegerFromUser();
			        	
			        	System.out.println("Please enter 1 for cars ($100/day per car), 2 for bikes ($60/day per bike), and 3 for trailers($40/day per trailer): ");
			        	int intType = ReadIntegerFromUser();
			        	
			        	String strType = "";
			        	String strHandles = "";
			        	int intMPG = 0;
			        	int intCost = 0;
			        	if (intType == 1)
			        	{
			        		strType = "Car";
			        		strHandles = "Steering Wheel";
			        		intMPG = 30;
			        		intCost = 100;
			        	}
			        	else if (intType == 2)
			        	{
			        		strType = "Motorbike";
			        		strHandles = "Handlebar";
			        		intMPG = 50;
			        		intCost = 60;
			        	}
			        	else
			        	{
			        		strType = "Trailer";
			        		strHandles = "Another Vehicle";
			        		intMPG = 0;
			        		intCost = 40;
			        	}
			        	
			        	int intTotalCost = intCost * intVehicles *  intDays;
			        	//End Input -----------------------------------------------------------------------------
			        	
		        		//Output --------------------------------------------------------------------------------
			        	System.out.print("\n" + "------------------------------------------------------" + "\n");
			        	System.out.print("\n" + "------------------------------------------------------" + "\n");
			        	System.out.print("\n" + "------------------------------------------------------" + "\n");
			        	System.out.print("Customer Name             : " + strName + "\n" );
			        	System.out.print("Phone Number              : " + strPhone + "\n" );
			        	System.out.print("Email                     : " + strEmail + "\n" );
			        	System.out.print("Type of Vehicles Rented   : " + strType + "\n" );
			        	System.out.print("Number of Vehicles Rented : " + intVehicles + "\n" );
			        	System.out.print("Days Rented               : " + intDays + "\n");
			        	System.out.print("Vehicle Information       : " + "MPG -  " + intMPG + " || Handles - " + strHandles + "\n");
			        	System.out.print("Cost Per Vehicle          : " + intCost + "\n");
			        	System.out.print("Total Cost                : " + intTotalCost + "\n");
			        	//End Output -----------------------------------------------------------------------------
		       		}
		        catch (Exception e ) {
		        			System.out.println("An I/O (location: input) error occured: " + e.getMessage());
		        		}
		       
		        //WARNING - THIS IS THE MAIN ENDING BRACKET
			}
			
			
			
			

			/** 
			 * 	method name: This will load the list from the table.	
			 */
			
			public static boolean LoadListFromDatabase( String strTable, String strPrimaryKeyColumn, String strNameColumn ) {
				
				//set flag to false
				boolean blnResult = false;
				
				try
				{
					String strSelect = "";
					Statement sqlCommand = null;
					ResultSet rstTSource = null;
					int intID = 0;
					String strType = "";
				
					// Build the SQL string
					strSelect = "SELECT " + strPrimaryKeyColumn + ", " + strNameColumn
								+ " FROM " + strTable
								+ " ORDER BY " + strNameColumn; 
							
					// Retrieve the all the records	
					sqlCommand = m_conAdministrator.createStatement( );
					rstTSource = sqlCommand.executeQuery( strSelect );
					// Loop through all the records
					while( rstTSource.next( ) == true )
					{
						// Get ID and Name from current row
						intID = rstTSource.getInt( 1 );
						strType = rstTSource.getString( 2 );
						// Print the list
						System.out.println("Table is: " + strTable + " Primary key: " + intID + " strType: " + strType);
					}
					// Clean up
					rstTSource.close( );
					sqlCommand.close( );
					// Success
					blnResult = true;
				}
				catch 	(Exception e) {
					System.out.println( "Error loading table" );
					System.out.println( "Error is " + e );
				}
				
				return blnResult;
				}

			/** 
			 * method name: OpenDatabaseConnectionMSAccess
			 * The opens the database connection	
			 * This requires the following drivers: Use UCanAccess, an open-source JDBC driver.
			 * Include the following jar files in your code:
			 *		ucanaccess-2.0.7.jar
			 *		jackcess-2.0.4.jar
			 *		commons-lang-2.6.jar
			 *		commons-logging-1.1.3.jar
			 *		hsqldb.jar
			 */
			
			public static boolean OpenDatabaseConnectionMSAccess( )
			{
				boolean blnResult = false;
				
				try {
					String strConnectionString = "";
					
					// Server name/port, IP address/port or path for file based DB like MS Access
					// System.getProperty( "user.dir" ) => Current working directory from where
					// application was started
					strConnectionString = "jdbc:ucanaccess://" + System.getProperty( "user.dir" )
										+ "\\Database\\dbHCM.accdb";
					// Open a connection to the database
					m_conAdministrator = DriverManager.getConnection( strConnectionString );
					// Success
					blnResult = true;
				}
				catch 	(Exception e) {
					System.out.println( "Try again - error in OpenDB ");
					System.out.println( "Error is " + e );
				}
				return blnResult;
			}
			
			/**
			 * OpenDatabaseConnectionSQLServer - get SQL db connection
			 * @return blnResult
			 */
			
			public static boolean OpenDatabaseConnectionSQLServer( )
			{
				boolean blnResult = false;
				
				try
				{
					SQLServerDataSource sdsTeamsAndPlayers = new SQLServerDataSource( );
					//tg-comment out --sdsTeamsAndPlayers.setServerName( "localhost" ); // localhost or IP or server name
					sdsTeamsAndPlayers.setServerName( "localhost\\SQLExpress" ); // SQL Express version
					sdsTeamsAndPlayers.setPortNumber( 1433 );
					sdsTeamsAndPlayers.setDatabaseName( "dbFinal" );
					
					// Login Type:
					
						// Windows Integrated
						//tg-comment out --sdsTeamsAndPlayers.setIntegratedSecurity( true );
						
						// OR
						
						// SQL Server
					     sdsTeamsAndPlayers.setUser( "sa" );
						 sdsTeamsAndPlayers.setPassword( "123" );	// Empty string "" for blank password
					
					// Open a connection to the database
					m_conAdministrator = sdsTeamsAndPlayers.getConnection(  );
					
					// Success
					blnResult = true;
				}
				catch( Exception excError )
				{
					// Display Error Message
					System.out.println( "Cannot connect - error: " + excError );

					// Warn about SQL Server JDBC Drivers
					System.out.println( "Make sure download MS SQL Server JDBC Drivers");
				}
				
				return blnResult;
			}
			
			
			/**
			* Name: CloseDatabaseConnection
			* Abstract: Close the connection to the database
			*/ 
			
			public static boolean CloseDatabaseConnection( )
			{
				boolean blnResult = false;
				
				try
				{
					// Is there a connection object?
					if( m_conAdministrator != null )
					{
						// Yes, close the connection if not closed already
						if( m_conAdministrator.isClosed( ) == false ) 
						{
							m_conAdministrator.close( );
							
							// Prevent JVM from crashing
							m_conAdministrator = null;
						}
					}
					// Success
					blnResult = true;
				}
				catch( Exception excError )
				{
					// Display Error Message
					System.out.println( excError );
				}
				
				return blnResult;
			}
			
			/**
			* Name: IsValidPhoneNumber
			* Abstract: Checks to make sure phone number is correctly formatted
			*/ 
			
			public static boolean IsValidPhoneNumber(String strPhoneNumber)
			{
				   boolean bool = false;
				   

			      Pattern pattern = Pattern.compile("\\d{3}-\\d{7}");
			      Matcher matcher = pattern.matcher(strPhoneNumber);
			      
			      if (matcher.matches()) {
			    	  System.out.println("Phone Number Valid");
			    	  bool = true;
			    	  
			      }
			      
			      else
			      {
			    	  System.out.println("Phone Number must be in the form XXX-XXXXXXX");
			    	  bool = false;
			      }
			      
			      return bool;
			}
			
			
			/**
			* Name: IsValidEmail
			* Abstract: Checks to make sure email is correctly formatted
			*/ 
			
			public static boolean IsValidEmail(String strEmail)
			{
				   boolean bool = false;

			      Pattern pattern = Pattern.compile("^(.+)@(.+)$");
			      Matcher matcher = pattern.matcher(strEmail);
			      
			      if (matcher.matches()) {
			    	  System.out.println("Email Valid");
			    	  bool = true;
			    	  
			      }
			      
			      else
			      {
			    	  System.out.println("Email must be in form name@domain.com");
			    	  bool = false;
			      }
			      
			      return bool;
			}
			
			
			/**
			* Name: ReadStringFromUser
			* Abstract: Reads string from user
			*/ 
			
			public static String ReadStringFromUser( )
			{			  

				String strBuffer = "";	
				
				try
				{
					
					// Input stream
					BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

					// Read a line from the user
					strBuffer = burInput.readLine( );
			
				}
				catch( Exception excError )
				{
					System.out.println( excError.toString( ) );
				}
				
				// Return integer value
				return strBuffer;		
			}
			
			
			
			/**
			* Name: ReadIntegerFromUser
			* Abstract: Reads Integer from user
			*/ 
			public static int ReadIntegerFromUser( )
			{
			
				int intValue = 0;
			
				try
				{
					String strBuffer = "";	
			
					// Input stream
					BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;
			
					// Read a line from the user
					strBuffer = burInput.readLine( );
					
					// Convert from string to integer
					intValue = Integer.parseInt( strBuffer );
				}
				catch( Exception excError )
				{
					System.out.println( excError.toString( ) );
				}
				
			
				// Return integer value
				return intValue;
			}

		

	}

