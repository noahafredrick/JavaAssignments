
public class Vehicle 
{
	// ----------------------------------------------------------------------
				// ----------------------------------------------------------------------
				// Properties
				// ----------------------------------------------------------------------
				// ----------------------------------------------------------------------
				// Never make public properties.  
				// Make protected or private with public get/set methods
				
				private int m_intWheels = 0;
				private int m_intMPG = 0;
				private String m_strHowToDrive = "";
				
				// ----------------------------------------------------------------------
				// ----------------------------------------------------------------------
				// Methods
				// ----------------------------------------------------------------------
				// ----------------------------------------------------------------------
				
				public void SetWheels( int intWheels )
				{
					m_intWheels = intWheels;
				}
				
				
				public int GetWheels( )
				{
					return m_intWheels;
				}
				
				
				public void SetMPG ( int intMPG )
				{
					m_intMPG = intMPG;
				}
				
				public int GetMPG( )
				{
					return m_intMPG;
				}
				
				public void SetHowToDrive(String strHowToDrive)
				{
					m_strHowToDrive = "";
				}
				
				public String GetHowToDrive()
				{
					return m_strHowToDrive;
				}
}
