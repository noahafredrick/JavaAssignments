-- --------------------------------------------------------------------------------
-- Name:		Noah Fredirck
-- Class:		IT-161 Java 1
-- Abstract:	DB Intro
-- --------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------
-- Options
-- --------------------------------------------------------------------------------
USE dbFinal 		            -- Don't work in master
SET NOCOUNT ON					-- Report only errors

-- ----------------------------------------------------------------------
-- Drops
-- ----------------------------------------------------------------------
IF OBJECT_ID( 'TVehicles' )						IS NOT NULL		DROP TABLE TVehicles

GO

-- ----------------------------------------------------------------------
-- Tables
-- ----------------------------------------------------------------------
CREATE TABLE TVehicles
(
	intVehicleID                     INTEGER        NOT NULL,
	strType							 VARCHAR(50)    NOT NULL,
	intWheels						 INTEGER		NOT NULL,
	strHowToDrive					 VARCHAR(50)    NOT NULL,
	intMPG							 INTEGER        NOT NULL,
	CONSTRAINT TVehicles_PK PRIMARY KEY CLUSTERED ( intVehicleID ))

-- Employees
INSERT INTO TVehicles( intVehicleID, strType, intWheels, strHowToDrive, intMPG )
VALUES ( 1, 'Car', 4, 'Steering Wheel', 25),
	   ( 2, 'Car', 4, 'Steering Wheel', 12),
	   ( 3, 'Motorbike', 2, 'Handlebars', 50),
	   ( 4, 'Motorbike', 2, 'Handlebars', 35),
	   ( 5, 'Trailer', 2, 'Another Vehicle', 0),
	   ( 6, 'Trailer', 2, 'Another Vehicle', 0);



GO

-- ----------------------------------------------------------------------
-- Testing
-- ----------------------------------------------------------------------
/*
SELECT * FROM TVehicles order by strType
*/

SELECT * FROM TVehicles ORDER BY strType