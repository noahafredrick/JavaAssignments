/*
 * Noah Fredrick
 * Java Programming 1
 * 1 November 2019
 * Tomie Gartland
 * 
 */

import java.io.*; 
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class PaystubTest2
{
	
	//-----------------------------------------------------------------------------------------------------------------------
	// Name: Void Main
	// Abstract: Where it all happens
	//-----------------------------------------------------------------------------------------------------------------------
	public static void main( String astrCommandLine[ ] )
	{
		String strEmployeeName = "0";
		double dblTotalGrossPay = 0;
		double dblTotalSocialTax = 0;
		double dblTotalMedicareTax = 0;
		double dblTotalFICATax = 0;
		double dblTotalWithheld = 0;
		double dblTotalNetEarnings = 0;
		DecimalFormat df = new DecimalFormat("###.##");
		
		//Input Part 1 - Collect Employee Name
		
		do
		{
			//Input Part 1 - Name
			
			System.out.println("Please enter the name of the employee - enter QUIT to exit ");
	        strEmployeeName = ReadStringFromUser();
	        strEmployeeName = strEmployeeName.toUpperCase();
			
	        //Input Part 2 - Wage
	        if(strEmployeeName.equals("QUIT")) {
	        	
	        } else {
	        System.out.println("Please enter the hourly wage of the employee: ");
	        double dblWage = ReadDoubleFromUser();
	        
	        //Input Part 3 - Hours
	        System.out.println("Please enter the hours worked of the employee: ");
	        double dblHours = ReadDoubleFromUser();
	        
	        //Input Part 4 - Withholding Exemptions
	        System.out.println("Please enter the exemptions of the employee: ");
	        double dblExemptions = ReadDoubleFromUser();
	        
	        //Input Part 5 - Marital Status
	        System.out.println("Please enter 0 if you are married and 1 if you are single");
	        double dblMaritalStatus = ReadDoubleFromUser(); 
	        
	        System.out.println("Information for employee " + strEmployeeName + ":\n");
	        
	        //Output Part 1 - Gross Pay
	        double dblGrossPay = payCalc(dblHours, dblWage);
	        System.out.println("Gross Pay: $" + df.format(dblGrossPay));
	        dblTotalGrossPay += dblGrossPay;
	        
	        //Output Part 2a - Social Security Tax
	        double dblSocialTax = dblGrossPay * 0.062;
	        System.out.println("Social Security Tax: $" + df.format(dblSocialTax));
	        dblTotalSocialTax += dblSocialTax;
	        
	      //Output Part 2b - Medicare Tax
	        double dblMedicareTax = dblGrossPay * 0.0145;
	        System.out.println("Medicare Tax: $" + df.format(dblMedicareTax));
	        dblTotalMedicareTax += dblMedicareTax;
	        
	      //Output Part 2c - FICA Tax
	        double dblFICATax = dblSocialTax + dblMedicareTax;
	        System.out.println("Total FICA Tax: $" + df.format(dblFICATax));
	        dblTotalFICATax += dblFICATax;
	        
	     //Output Part 3 - Withholdings
	        double dblAdjustedGrossIncome = dblGrossPay - (55.77 * dblExemptions);
	        double dblFederalTaxWithholdings = 0;
	        
	        //If single
	        if(dblMaritalStatus == 1) {
	        	if(dblAdjustedGrossIncome < 51) 
	        	{
	        		dblFederalTaxWithholdings = 0;
	        	}
	        	else if((dblAdjustedGrossIncome < 501) && (dblAdjustedGrossIncome > 50)) 
	        	{
	        		dblFederalTaxWithholdings = (dblAdjustedGrossIncome - 51) * .1;
	        	}
	        	else if((dblAdjustedGrossIncome < 2501) && (dblAdjustedGrossIncome > 500)) 
	        	{
	        		dblFederalTaxWithholdings = 45 + (dblAdjustedGrossIncome - 500)  * .15;
	        	}
	        	else if((dblAdjustedGrossIncome < 5001) && (dblAdjustedGrossIncome > 2500)) 
	        	{
	        		dblFederalTaxWithholdings = 345 + (dblAdjustedGrossIncome - 2500)  * .2;
	        	}
	        	else 
	        	{
	        		dblFederalTaxWithholdings = 845 + (dblAdjustedGrossIncome - 5000) * .25;
	        	}
	        }
	        	
	        //If Married
	        if(dblMaritalStatus == 0) {
	        	if(dblAdjustedGrossIncome < 51) 
	        	{
	        		dblFederalTaxWithholdings = 0;
	        	}
	        	else if((dblAdjustedGrossIncome < 501) && (dblAdjustedGrossIncome > 50)) 
	        	{
	        		dblFederalTaxWithholdings = (dblAdjustedGrossIncome - 51) * .05;
	        	}
	        	else if((dblAdjustedGrossIncome < 2501) && (dblAdjustedGrossIncome > 500)) 
	        	{
	        		dblFederalTaxWithholdings = 22.50 + (dblAdjustedGrossIncome - 500)  * .1;
	        	}
	        	else if((dblAdjustedGrossIncome < 5001) && (dblAdjustedGrossIncome > 2500)) 
	        	{
	        		dblFederalTaxWithholdings = 225.50 + (dblAdjustedGrossIncome - 2500)  * .15;
	        	}
	        	else 
	        	{
	        		dblFederalTaxWithholdings = 600.50 + (dblAdjustedGrossIncome - 5000) * .2;
	        	}
	        }
	        
	        System.out.println("Federal Income Tax Withholdings: $" + df.format(dblFederalTaxWithholdings));
	        dblTotalWithheld += dblFederalTaxWithholdings;
	        
	     //Output Part 4 - Net Earnings
	        double dblNetEarnings = dblGrossPay - dblFICATax - dblFederalTaxWithholdings;
	        System.out.println("Net Earnings: $" + df.format(dblNetEarnings));
	        dblTotalNetEarnings += dblNetEarnings;
	        
	        
	        }
		}while( !strEmployeeName.equals("QUIT"));
		
		
		 //Grand Payroll
		 System.out.println("\nGrand Gross Pay: $" + df.format(dblTotalGrossPay));
		 System.out.println("Grand Social Security Tax: $" + df.format(dblTotalSocialTax));
		 System.out.println("Grand Medicare Tax: $" + df.format(dblTotalMedicareTax));
		 System.out.println("Grand FICA Tax: $" + df.format(dblTotalFICATax));
		 System.out.println("Grand Federal Income Tax Withholdings: $" + df.format(dblTotalWithheld));
		 System.out.println("Grand Net Earnings: $" + df.format(dblTotalNetEarnings));
	}
		//-----------------------------------------------------------------------------------------------------------------------
		// Name: payCalc
		// Abstract: Calculates pay (including overtime) for the user
		//-----------------------------------------------------------------------------------------------------------------------
		public static double payCalc(double hoursWorked, double payRate) {
			double dblPay = 0;
			
			//If no overtime
			if(hoursWorked <= 40) {
				dblPay = hoursWorked * payRate;
			}
			
			//If overtime
			else if(hoursWorked > 40) {
				double dblFirstFortyPay = 0;
				double dblOvertime = 0;
				double dblOverPay = 0;
				double dblOverRate = payRate * 1.5;
				
				//Calculate first forty hours of pay
				dblFirstFortyPay = payRate * 40;
				
				//Determine hours of overtime
				dblOvertime = hoursWorked - 40;
				
				//Determine overtime pay
				dblOverPay = dblOverRate * dblOvertime;
				
				//The total amount payed
				dblPay = dblFirstFortyPay + dblOverPay;
			}
			
			return dblPay;
		}
		
		
		//-----------------------------------------------------------------------------------------------------------------------
		// Name: ReadIntegerFromUser
		// Abstract: Read an integer from the user
		//-----------------------------------------------------------------------------------------------------------------------
		public static int ReadIntegerFromUser( )
		{
		
			int intValue = 0;
		
			try
			{
				String strBuffer = "";	
		
				// Input stream
				BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;
		
				// Read a line from the user
				strBuffer = burInput.readLine( );
				
				// Convert from string to integer
				intValue = Integer.parseInt( strBuffer );
			}
			catch( Exception excError )
			{
				System.out.println( excError.toString( ) );
			}
			
		
			// Return integer value
			return intValue;
		}
		
		//-----------------------------------------------------------------------------------------------------------------------
		// Name: ReadStringFromUser
		// Abstract: Read an integer from the user
		//-----------------------------------------------------------------------------------------------------------------------
		public static String ReadStringFromUser( )
		{			  

			String strBuffer = "";	
			
			try
			{
				
				// Input stream
				BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

				// Read a line from the user
				strBuffer = burInput.readLine( );
		
			}
			catch( Exception excError )
			{
				System.out.println( excError.toString( ) );
			}
			
			// Return integer value
			return strBuffer;		
		}
			
			//-----------------------------------------------------------------------------------------------------------------------
			// Name: ReadFloatFromUser
			// Abstract: Read a float from the user
			//-----------------------------------------------------------------------------------------------------------------------
			public static double ReadDoubleFromUser( )
			{

				double dblValue = 0;

				try
				{
					String strBuffer = "";	

					// Input stream
					BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

					// Read a line from the user
					strBuffer = burInput.readLine( );
					
					// Convert from string to float
					dblValue = Double.parseDouble( strBuffer );
				}
				catch( Exception excError )
				{
					System.out.println( excError.toString( ) );
				}
				

				// Return float value
				return dblValue;
				}
		
}

