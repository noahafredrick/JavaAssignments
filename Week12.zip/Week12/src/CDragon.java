//Dragon CLASS
				public class CDragon extends CAnimal
				{
					private int m_intHeadCount = 1;
					
					
					public void SetHeads(int intHeadCount) 
					{
						//Negative?
								if(intHeadCount < 0)
								{
									intHeadCount = 1;
								}
								m_intHeadCount = intHeadCount;
					}
					
					public int GetHeads()
					{
						return m_intHeadCount;
					}
					
					
					public void MakeNoise()
					{
						System.out.println("Roar!!!!");
					}
					
					public void BreatheFire()
					{
						int intIndex = 0;
						
						if(GetHeads() == 1)
						{
							System.out.println("The dragon breathes fire.");
						}
						else 
						{
							System.out.println("The dragon breathes fire from each of its " + GetHeads() + " heads:");
							for(intIndex = 0; intIndex <GetHeads(); intIndex+=1)
							{
								System.out.println("***Breathes fire!***");
							}
						}
					}
					
				}
