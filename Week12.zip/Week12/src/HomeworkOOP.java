/*
 * Noah Fredrick
 * Java Programming 1
 * 1 November 2019
 * Tomie Gartland
 * 
 */

import java.io.*; 

public class HomeworkOOP {
		//-----------------------------------------------------------------------------------------------------------------------
		// Name: Void Main
		// Abstract: Where it all happens
		//-----------------------------------------------------------------------------------------------------------------------
		public static void main( String astrCommandLine[ ]) {
		//ShowPolyformism();	    
		  Step1ConstructorsAndOverloading();
		  Step2InheritanceAndSuper();
		}
		

		static void ShowPolyformism()
		{
			//Populate the zoo
			CAnimal[] aclsZoo = new CAnimal[7];

			CDog clsBuster = new CDog();
			clsBuster.SetType("Dog");
			clsBuster.SetName("Buster");
			clsBuster.SetAge(11);
			clsBuster.SetWeight(40);

			CCat clsSunny = new CCat();
			clsSunny.SetName("Sunny");
			clsSunny.SetType("Cat");

			CDuck clsDaffy = new CDuck();
			clsDaffy.SetName("Daffy");
			clsDaffy.SetType("Duck");

			CCow clsBessie = new CCow();
			clsBessie.SetName("Bessie");
			clsBessie.SetType("Cow");
			clsBessie.SetColor("");

			CDragon clsSmaugh = new CDragon();
			clsSmaugh.SetName("Smaugh");
			clsSmaugh.SetType("Dragon");
			clsSmaugh.SetHeads(3);

			CTrainedDog clsFifi = new CTrainedDog();
			clsFifi.SetName("Fifi");
			clsFifi.SetType("Trained Dog");
			clsFifi.SetAge(2);
			clsFifi.SetWeight(10);
			clsFifi.SetBreed("Poodle");


			aclsZoo[0] = (CAnimal)clsBuster;
			aclsZoo[1] = (CAnimal)clsSunny;
			aclsZoo[2] = (CAnimal)clsDaffy;
			aclsZoo[3] = null;
			aclsZoo[4] = (CAnimal)clsBessie;
			aclsZoo[5] = (CAnimal)clsSmaugh;
			aclsZoo[6] = (CAnimal)clsFifi;

			for(int intIndex = 0; intIndex < aclsZoo.length; intIndex += 1)
				{
				if(aclsZoo[intIndex]!= null)
				{
					System.out.println("Animal in cage #" + (intIndex + 1));
					System.out.println("Name: " + aclsZoo[intIndex].GetName());
					System.out.println("Type: " + aclsZoo[intIndex].GetType());
					aclsZoo[intIndex].MakeNoise();
		
					String strAnimalType = "";
		
					strAnimalType = aclsZoo[intIndex].GetType();
		
					if(strAnimalType.equals("Dog") == true)
					{
						((CDog)aclsZoo[intIndex]).Fetch();
					}
		
					else if (strAnimalType.contentEquals("Trained Dog") == true)
					{
						((CTrainedDog) aclsZoo[intIndex]).PlayDead();
						((CTrainedDog) aclsZoo[intIndex]).Print();
					}
					else if (strAnimalType.equals("Cow") == true)
					{
						((CCow) aclsZoo[intIndex]).Graze();
						System.out.println("Color is: " +((CCow) aclsZoo[intIndex]).GetColor());
					}
		
					else if(strAnimalType.equals("Dragon") == true)
					{
						((CDragon) aclsZoo[intIndex]).BreatheFire();
					}
		
					System.out.println("");
		
		
					}
				}
			//End of show polyformism
		}
		
		public static void Step1ConstructorsAndOverloading()
			{
				System.out.println("Step 1 - Constructors and Overloading");
				System.out.println("---------------------------------------");
				
				CDog clsBuster1 = new CDog();
				CDog clsBuster2 = new CDog("Buster2");
				CDog clsBuster3 = new CDog("Buster3", 11);
				CDog clsBuster4 = new CDog("Buster4", 11, 40);
				
				clsBuster1.Print();
				clsBuster2.Print();
				clsBuster3.Print();
				clsBuster4.Print();
			}
		
		public static void Step2InheritanceAndSuper()
			{
				System.out.println("Step 2 - Inheritance and Super");
				System.out.println("---------------------------------------");
			
				CDog clsSuperBuster1 = new CTrainedDog();
				CDog clsSuperBuster2 = new CTrainedDog("SuperBuster2");
				CDog clsSuperBuster3 = new CTrainedDog("SuperBuster3", 11);
				CDog clsSuperBuster4 = new CTrainedDog("SuperBuster4", 11, 40);
				CDog clsSuperBuster5 = new CTrainedDog("SuperBuster4", 11, 40, "Basset Hound");
			
				clsSuperBuster1.Print();
				clsSuperBuster2.Print();
				clsSuperBuster3.Print();
				clsSuperBuster4.Print();
				clsSuperBuster5.Print();
			}
		
		}

