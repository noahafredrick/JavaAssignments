//Cow CLASS
				public class CCow extends CAnimal
				{
					private String m_strColor = "";
					
					
					public void SetColor(String strNewColor)
					{
						int intStopIndex = 0;
						
						//Brown by default
						if(strNewColor.equals("") == true)strNewColor = "Brown";
						
						intStopIndex = strNewColor.length();
						if(intStopIndex > 10)
						{
							intStopIndex = 10;
						}
						
						m_strColor = strNewColor.substring(0, intStopIndex);
					}
					
					public String GetColor()
					{
						return m_strColor;
					}
					
					public void Graze()
					{
						System.out.println("Mmmm, this is some tasty grass.");
					}
					
					public void MakeNoise()
					{
					System.out.println("Moo!");
					}
				}
