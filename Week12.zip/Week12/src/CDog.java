//DOG CLASS
		public class CDog extends CAnimal
		{
			// ----------------------------------------------------------------------
			// ----------------------------------------------------------------------
			// Properties
			// ----------------------------------------------------------------------
			// ----------------------------------------------------------------------
			// Never make public properties.  
			// Make protected or private with public get/set methods
			private Float m_sngWeight = 0.0f;
			private int m_intAge = 0;
			// ----------------------------------------------------------------------
			// ----------------------------------------------------------------------
			// Methods
			// ----------------------------------------------------------------------
			// ----------------------------------------------------------------------
			
			//SetWeight
			public void SetWeight(float sngNewWeight)
			{
				//Negative?
				if(sngNewWeight < 0)
				{
					sngNewWeight = 0.0f;
				}
				m_sngWeight = sngNewWeight;
			}
			
			
			
			
			//GetWeight
			public float GetWeight()
			{
				return m_sngWeight;
			}
			
			
			
			
			//SetAge
			public void SetAge(int intNewAge)
			{
				//Negative?
				if(intNewAge < 0)
				{
					intNewAge = 0;
				}
				
				m_intAge = intNewAge;
			}
			
			
			
			//Get Age
			public int GetAge()
			{
				return m_intAge;
			}
			
			
			
			//Bark
			public void MakeNoise( )
			{
				//Big dog?
				if(GetWeight() < 15)
				{
					//Little doggy
					System.out.println("Yip yip yip");
				}
				else
				{
				System.out.println( "Woof" );
				}
			}
			
			
			public void Fetch()
			{
				if(GetAge() > 10)
				{
					System.out.print("Woah, woah, woah. \n"
									+ "How about you fetch the stick this time.\n"
									+ "And some bacon.\n");
				}
				else 
				{
					System.out.println("Fetching the tasty stick");
				}
			}
			
			
			public void Initialize(String strName, int intAge, float sngWeight)
			{
				SetType("Dog");
				SetName(strName);
				SetAge(intAge);
				SetWeight(sngWeight);
			}
			
			
			//Basic Constructor
			public CDog()
			{
				Initialize("", 0, 0);
			}
			
			//Parametized Constructors
			public CDog(String strName) 
			{
				Initialize(strName, 0, 0);
			
			}
			
			public CDog(String strName, int intAge)
			{
				Initialize(strName, intAge, 0);
			}
			
			public CDog(String strName, int intAge, float sngWeight)
			{
			Initialize(strName, intAge, sngWeight);
			}
			
			//Print
			public void Print()
			{
				System.out.println("Name:   " + GetName());
				System.out.println("Age:    " + GetAge());
				System.out.println("Weight: " + GetWeight());
				
				//Methods
				MakeNoise();
				Fetch();
				
				System.out.println("");
				System.out.println("");
			}
		 
		}