//CAT CLASS
				public class CCat extends CAnimal
				{
					public void MakeNoise()
					{
					System.out.println("Meow!");
					}
				}