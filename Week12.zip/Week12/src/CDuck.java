
//DUCK CLASS
				public class CDuck extends CAnimal
				{
					public void MakeNoise()
					{
					System.out.println("Quack!");
					}
				}
